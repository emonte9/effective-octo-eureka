import Foundation
import CoreData


extension Dish {
    //MenuItem
    static func createDishesFrom(menuItems:[MenuItem],
                                 _ context:NSManagedObjectContext) {
        
        for menuItem in menuItems {
            if  let exist = exists(name: menuItem.title, context), exist {
               continue
                
            } else{
                let dish = Dish(context: context)
                dish.name = menuItem.title
                dish.price = Float(menuItem.price) ?? 0.0
            }
        }
        
        
        
        do{
            try context.save()
        }catch{
            print("error at Dish+Extension")
        }
        
    }
    
}
