import SwiftUI
import CoreData

struct OurDishes: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @ObservedObject var dishesModel = DishesModel()
    @State private var showAlert = false
    @State var searchText = ""
    
    
    var body: some View {
        VStack {
            LittleLemonLogo()
                .padding(.bottom, 10)
                .padding(.top, 50)
            
            Text ("Tap to order")
                .foregroundColor(.black)
                .padding([.leading, .trailing], 40)
                .padding([.top, .bottom], 8)
                .background(Color("approvedYellow"))
                .cornerRadius(20)
            
            
            NavigationView {
                FetchedObjects(
                    predicate:buildPredicate(searchText: searchText),
                    sortDescriptors: buildSortDescriptors()) {
                        (dishes: [Dish]) in
                        List {
                            
                          ForEach(dishes, id: \.self){dish in
                              
                              DisplayDish(dish).onTapGesture {
                                  showAlert = true
                              }
                            }
                            // Code for the list enumeration here
                        }
                        // add the search bar modifier here
                    }
            }.searchable(text: $searchText, prompt: "Search...")
            
            // SwiftUI has this space between the title and the list
            // that is amost impossible to remove without incurring
            // into complex steps that run out of the scope of this
            // course, so, this is a hack, to bring the list up
            // try to comment this line and see what happens.
            .padding(.top, -10)//
            
            .alert("Order placed, thanks!",
                   isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            }
            
            // makes the list background invisible, default is gray
                   .scrollContentBackground(.hidden)
            
            // runs when the view appears
                   .task {
                       await dishesModel.reload(viewContext)
                   }
            
        }
    }
}

private func buildPredicate(searchText: String) -> NSPredicate {
    if searchText.isEmpty {
        return NSPredicate(value: true)
    } else {
        return NSPredicate(format: "name CONTAINS[cd] %@", searchText)
    }
    
//    let predicate1 = NSPredicate(format: "productPrice < %@)", 100)
//    let predicate2 = NSPredicate(format: "customerName CONTAINS[cd] %@",
//    "John Doe")
//
//    let compoundPredicate = NSCompoundPredicate(type: .and,
//    subpredicates: [predicate1, predicate2])
}

private func buildSortDescriptors() -> [NSSortDescriptor] {
//    return [NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedCompare(_:)))]
    return [NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedCompare)),
        NSSortDescriptor(key: "size", ascending: true, selector: #selector(NSString.localizedCompare))
    ]
}

struct OurDishes_Previews: PreviewProvider {
    static var previews: some View {
        OurDishes()
    }
}
